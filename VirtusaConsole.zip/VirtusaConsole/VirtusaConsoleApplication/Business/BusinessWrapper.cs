﻿using System;
using VirtusaConsoleApplication.ExceptionHelper;
using VirtusaConsoleApplication.ExceptionHelper.Interface;
using VirtusaConsoleApplication.GenericHelper;
using VirtusaConsoleApplication.GenericHelper.Interface;


namespace VirtusaConsoleApplication.Business
{
    /// <summary>
    ///  This class will be responsible to hold the business implementation
    /// </summary>
    public class BusinessWrapper
    {
        /// <summary>
        /// Variable to hold Instance of Logger
        /// </summary>
        private readonly ILogger _logger;

        /// <summary>
        /// variable to hold the Instance of helper class
        /// </summary>
        private readonly IHelper _helper;

        /// <summary>
        ///  Global variable to hold the hour text once in memory 
        /// </summary>
        private string hourText = string.Empty;

        /// <summary>
        /// Global variable to hold the min text once in memory 
        /// </summary>
        private string minText = string.Empty;

        /// <summary>
        /// Global variable to hold the next hour text once in memory 
        /// </summary>
        private string nextHourText = string.Empty;

        /// <summary>
        /// Global variable to hold the remainingMin text once in memory 
        /// </summary>
        private string remainingMinText = string.Empty;

        /// <summary>
        ///  Internal constructor to be used for unit testing
        /// </summary>
        /// <param name="logger"></param>
        /// <param name="helper"></param>
        internal BusinessWrapper(ILogger logger, IHelper helper)
        {
            _logger = logger;
            _helper = helper;
        }

        /// <summary>
        /// Public constructor to be instantiated without injection
        /// </summary>
        public BusinessWrapper() : this(Logger.Instance, new Helper())
        {

        }

        /// <summary>
        /// This method will extract the hour and minutes and send for the text
        /// and produce combined text
        /// </summary>
        /// <param name="time"></param>
        /// <returns></returns>
        public string ConvertTimeInWords(TimeSpan time)
        {
            //Below line will identify if hour value is more than 12
            var hourNow = time.Hours > 12 ? (time.Hours - 12) : time.Hours;

            //Below line will generate and hold the text for hour
            hourText = _helper.ConvertHoursAndMinsInWord(hourNow);

            //Below line will generate and hold the text for min
            minText = _helper.ConvertHoursAndMinsInWord(time.Minutes);

            //Below line will generate and hold the text for Next hour
            nextHourText = _helper.ConvertHoursAndMinsInWord(hourNow + 1);

            //Below line will generate and hold the text for remaning mins in next hour
            remainingMinText = _helper.ConvertHoursAndMinsInWord(time.Minutes > 30 ? (60 - time.Minutes) : time.Minutes);

            // Call the final text method and extract the final text
            return FetchFinalText(time.Hours, time.Minutes);
        }

        /// <summary>
        /// This method will generate the final text
        /// </summary>
        /// <param name="hour"></param>
        /// <param name="minutes"></param>
        /// <returns></returns>
        private string FetchFinalText(int hour, int minutes)
        {
            // To hole the value
            var finalText = string.Empty;

            // Switch case based on the conditions
            switch (minutes)
            {
                case 0:
                    finalText = $"{hourText} O'clock";
                    break;
                case int n when n < 30:
                    finalText = $"{minText} past {hourText}";
                    break;

                case 30:
                    finalText = $"half past {hourText}";
                    break;
                case int n when n > 30:
                    finalText = $"{remainingMinText} to {nextHourText}";
                    break;
            }
            return finalText;
        }

    }


}
