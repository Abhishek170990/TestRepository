﻿using System;
using System.Diagnostics;
using System.Text;
using VirtusaConsoleApplication.ExceptionHelper;
using VirtusaConsoleApplication.ExceptionHelper.Interface;
using VirtusaConsoleApplication.GenericHelper.Interface;

namespace VirtusaConsoleApplication.GenericHelper
{

    /// <summary>
    /// This is a helper class to extract the text of number and method name
    /// </summary>
    public class Helper :IHelper
    {
        /// <summary>
        /// Variable to hold Instance of Logger
        /// </summary>
        private readonly ILogger _logger;

        /// <summary>
        /// Variable to hold Instance of Helper
        /// </summary>
        private static IHelper _instance = new Helper();

        /// <summary>
        /// Internal constructor for the unit testing
        /// </summary>
        /// <param name="logger"></param>
        internal Helper(ILogger logger)
        {
            _logger = logger;
        }

        /// <summary>
        /// Public constructor for instantiation
        /// </summary>
        public Helper():this(new Logger())
        {

        }

        /// <summary>
        /// Static instance of the class
        /// </summary>
        public static IHelper Instance
        {
            get { return _instance; }
        }


        /// <summary>
        /// This method will convert the Hours and mins value in the words
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        public string ConvertHoursAndMinsInWord(int number)
        {
            var word = new StringBuilder();
            var ones = new[] { "Zero", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine" };
            var elevensMap = new[] { "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen", "Sixteen", "Seventeen", "Eighteen", "Nineteen" };
            var tensMap = new[] { "zero", "Ten", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety" };
            var divNumber = number / 10;
            var modNumber = number % 10;
            word.Append(divNumber == 0 ? ones[modNumber] : (divNumber == 1 ? (modNumber == 0 ? elevensMap[0] : elevensMap[modNumber]) : (tensMap[divNumber] + " " + (modNumber == 0 ? string.Empty : ones[modNumber]))));
            return word.ToString();
        }


        /// <summary>
        /// This method will fetch the caller method name
        /// </summary>
        /// <returns></returns>
        public string FetchCallerName()
        {
            return new StackTrace().GetFrame(1).GetMethod().Name;
        }
    }
}
