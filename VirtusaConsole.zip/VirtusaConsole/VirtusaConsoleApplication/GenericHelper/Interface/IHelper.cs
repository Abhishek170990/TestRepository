﻿namespace VirtusaConsoleApplication.GenericHelper.Interface
{
    /// <summary>
    /// Interface for helper class
    /// </summary>
    public interface IHelper
    {
        /// <summary>
        /// This method will convert the Hours and mins value in the words
        /// </summary>
        /// <param name="number"></param>
        /// <returns></returns>
        string ConvertHoursAndMinsInWord(int number);

        /// <summary>
        /// This method will fetch the caller method name
        /// </summary>
        /// <returns></returns>
        string FetchCallerName();   
    }
}
