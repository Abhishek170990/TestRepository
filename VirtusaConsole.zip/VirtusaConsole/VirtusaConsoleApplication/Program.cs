﻿using System;
using VirtusaConsoleApplication.Business;
using VirtusaConsoleApplication.ExceptionHelper;
using VirtusaConsoleApplication.GenericHelper;

namespace VirtusaConsoleApplication
{
    class MainClass
    {
        /// <summary>
        /// landing Method to be called first
        /// </summary>
        /// <param name="args"></param>

        public static void Main(string[] args)
        {
            Console.WriteLine($"Welcome to console. This console will provide the human friendly text for a time span. You can provide any input or simply press enter to get the current time");
            TimeSpan timeInput;
            // Instance of Logger componet
            var _logger = Logger.Instance;

            //Instance of Helper component
            var _helper = Helper.Instance;
            try
            {
                // Logging the info of method entry
                _logger.LogInfo($"Call started for method {_helper.FetchCallerName()}");

                // Object creation for BusinessWrapperClass
                var businessWrapper = new BusinessWrapper();

                // variable to read inputs
                var input = Console.ReadLine();
                
                try
                {
                    //Reading the input from the commandß

                    timeInput = (input == string.Empty? DateTime.Now.TimeOfDay: TimeSpan.Parse(input));
                }
                catch 
                {
                    throw new Exception(message: $"Provided value for time stamp is incorrect please exit the program and provide the correct value");
                }
                //Logging the call complete of the method
                _logger.LogInfo($"Call completed for method {_helper.FetchCallerName()}");
                Console.WriteLine(businessWrapper.ConvertTimeInWords(timeInput));

            }
            catch (Exception ex)
            {
                // Logging the exception
                _logger.LogException(ex);

                // Throw the appropriate message to caller

                throw new Exception(message: $"Exception occured in method {_helper.FetchCallerName()}. Error Message : {ex.Message}");
            }
        }


    }
}


