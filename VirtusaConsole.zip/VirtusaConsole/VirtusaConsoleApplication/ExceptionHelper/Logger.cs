﻿using System;
using System.Diagnostics;
using System.IO;
using VirtusaConsoleApplication.ExceptionHelper.Interface;

namespace VirtusaConsoleApplication.ExceptionHelper
{
    /// <summary>
    /// This class will log the exception and audit info 
    /// </summary>
    public class Logger : ILogger
    {
        /// <summary>
        /// Static instance variable
        /// </summary>
        private static ILogger _instance = new Logger();

        /// <summary>
        /// Static instance
        /// </summary>
        public static ILogger Instance
        {
            get { return _instance; }
        }

        /// <summary>
        /// This method will Log the exception
        /// </summary>
        /// <param name="ex"></param>
        public void LogException(Exception ex)
        {
            var ExceptionMessage = $"Exception occcured in method { new StackTrace().GetFrame(1).GetMethod().Name}. Exception Message  : {ex.Message} \n Stack Trace : {ex.StackTrace}";
            WriteToNotepad(ExceptionMessage, true);
        }

        /// <summary>
        /// This method will log the audit information
        /// </summary>
        /// <param name="message"></param>
        public void LogInfo(string message)
        {
            WriteToNotepad(message);
        }

        /// <summary>
        /// This method will write the message in notepad
        /// </summary>
        /// <param name="message"></param>
        /// <param name="isException"></param>
        public void WriteToNotepad(string message, bool isException = false)
        {
            var LogInfoFileName = "InfoLog.txt";

            var LogExceptionFileName = "ExceptionLog.txt";

            //Pass the filepath and filename to the StreamWriter Constructor
            using (StreamWriter sw = new StreamWriter(isException ? LogExceptionFileName : LogInfoFileName))
            {
                //Write a line of text
                sw.WriteLine(message);
            }
        }

    }



}
