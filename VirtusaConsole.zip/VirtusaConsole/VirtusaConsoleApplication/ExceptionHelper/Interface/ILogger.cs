﻿using System;
namespace VirtusaConsoleApplication.ExceptionHelper.Interface
{
    /// <summary>
    /// Interface for Logger class
    /// </summary>
    public interface ILogger
    {
        /// <summary>
        ///  Method to log the audit information
        /// </summary>
        /// <param name="message"></param>
        void LogInfo(string message);

        /// <summary>
        /// Method to log the exception
        /// </summary>
        /// <param name="ex"></param>
        void LogException(Exception ex);
    }
}
